====================================================================
8WHIE OFFICIAL INFINITYFREE HTDOCS DEPLOYMENT GUIDE
Target Domain: https://8whie.page.gd
Founder: Aryan Thakur
Brand: 8WHIE (Worldwide Hackers Intelligence & Ethics)
====================================================================

HOW TO DEPLOY TO INFINITYFREE:
1. Log in to your InfinityFree control panel (https://dash.infinityfree.com).
2. Open the Online File Manager (or connect using FileZilla FTP).
3. Open the "htdocs" folder for 8whie.page.gd.
4. Upload all files and folders extracted from this ZIP directly into "htdocs":
   - index.html
   - .htaccess
   - robots.txt
   - sitemap.xml
   - favicon.svg
   - assets/ (all JavaScript and CSS bundles)
5. Visit https://8whie.page.gd in your browser!
====================================================================